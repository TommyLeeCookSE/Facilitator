from badgeAutomator import *

badgeFileReader()